<template>
  
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component({
  name: 'Name'
})
export default class Name extends Vue {
}
</script>

<style lang="scss" scoped>

</style>